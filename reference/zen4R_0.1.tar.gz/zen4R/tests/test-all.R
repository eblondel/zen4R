library(testthat)
library(zen4R)

test_check("zen4R")